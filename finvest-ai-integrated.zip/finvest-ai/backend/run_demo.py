"""
Quick end-to-end demo without needing to start the API server.

Usage:
    python run_demo.py                       # runs a default scenario
    python run_demo.py RELIANCE user_aggressive_01
    python run_demo.py TCS user_moderate_01 --degrade    # force degraded feed first
"""
from __future__ import annotations

import asyncio
import sys

from app.data_feed import feed
from app.orchestrator import run_session


async def main() -> None:
    args = sys.argv[1:]
    degrade = "--degrade" in args
    args = [a for a in args if a != "--degrade"]

    ticker = args[0].upper() if len(args) >= 1 else "RELIANCE"
    user_id = args[1] if len(args) >= 2 else "user_moderate_01"

    if degrade:
        feed.set_degraded(ticker, True)
        print(f"[demo] forced {ticker} feed into a degraded state\n")

    result = await run_session(ticker, user_id)

    print(f"=== Analysis: {result.ticker} for {result.user_id} ===\n")
    for output in result.agent_outputs:
        flag = " [DEGRADED]" if output.degraded else ""
        print(f"- {output.agent_name} ({output.dimension}){flag}")
        print(f"    label: {output.label} | confidence: {output.confidence}")
        print(f"    reasoning: {output.reasoning}")
        if output.citations:
            for c in output.citations:
                print(f"    citation: [{c.source}] (score={c.score}) \"{c.snippet}\"")
        print()

    print("=== Synthesis ===")
    print(f"recommendation: {result.recommendation}")
    print(f"confidence:     {result.confidence}")
    print(f"degraded_inputs: {result.degraded_inputs}")
    print(f"summary: {result.summary}")


if __name__ == "__main__":
    asyncio.run(main())
