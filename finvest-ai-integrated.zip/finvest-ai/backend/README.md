# PS-01 Backend — Multi-Agent Autonomous Financial Intelligence System

A working FastAPI backend for HackVerse PS-01. It turns simulated market data
+ a synthetic filings/earnings corpus into an explainable, per-user,
source-attributed investment recommendation, via three parallel signal
agents and a synthesis layer.

**Runs fully offline, no API keys required.** RAG retrieval uses TF-IDF
(scikit-learn) instead of an embeddings API, and reasoning is generated with
deterministic templates instead of an LLM call — both swappable (see
"Extending" below) without touching the pipeline's shape.

## Quickstart

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Option A: one-shot CLI demo, no server needed
python run_demo.py RELIANCE user_conservative_01
python run_demo.py TCS user_aggressive_01 --degrade   # forces a degraded-feed scenario

# Option B: run the API
uvicorn app.main:app --reload --port 8000
# then open http://localhost:8000/docs
```

Try it: `GET /analyze/RELIANCE?user_id=user_conservative_01` vs
`GET /analyze/RELIANCE?user_id=user_aggressive_01` — same market input,
different recommendation, because the synthesis layer weights output by
each user's stored risk tolerance and existing portfolio concentration.

## Architecture

```
                        ┌─────────────────┐
   market data ────────▶│  MarketDataFeed  │  (simulated NSE-style feed;
   (data_feed.py)       │  (data_feed.py)  │   can be forced "degraded")
                        └────────┬─────────┘
                                 │ MarketSnapshot
                 ┌───────────────┼───────────────┐
                 ▼               ▼               ▼
         ┌──────────────┐ ┌──────────────┐ ┌──────────────────┐
         │ MomentumAgent│ │ VolumeAgent  │ │ SentimentAgent    │
         │ (price ROC + │ │ (volume vs   │ │ (TF-IDF retrieval │
         │  MA spread)  │ │  20d avg)    │ │  over corpus.py + │
         │              │ │              │ │  lexicon scoring) │
         └──────┬───────┘ └──────┬───────┘ └─────────┬─────────┘
                │  asyncio.gather (parallel)          │
                └───────────────┬──────────────────────┘
                                 ▼ List[AgentOutput]
                        ┌─────────────────┐        ┌──────────────┐
                        │  SynthesisAgent │◀───────│ UserProfile   │
                        │ (weights signal │        │ (risk, port-  │
                        │  by risk +      │        │  folio, watch-│
                        │  concentration) │        │  list)        │
                        └────────┬────────┘        └──────────────┘
                                 ▼
                        SynthesisResult (cited, explainable)
                                 │
                     ┌───────────┴────────────┐
                     ▼                         ▼
            SessionMetrics logged      returned via REST / WebSocket
            (logger.py, JSONL)          (main.py)
```

**Orchestrator (`orchestrator.py`)** dispatches all three agents concurrently
with `asyncio.gather`, wraps each in a try/except so one agent failing
degrades only that dimension (label `neutral`, confidence `0.0`, flagged
`degraded=True`) instead of crashing the session, then calls the synthesis
layer and logs metrics.

**Decision logic in the synthesis layer:** momentum + sentiment labels are
converted to a signed score, weighted by each agent's own confidence, then
scaled by (a) a volume amplifier if volume is elevated, (b) a risk
multiplier (`conservative` 0.7x / `moderate` 1.0x / `aggressive` 1.3x), and
(c) a concentration penalty — the more of a ticker a user already holds, the
less the system pushes to add more, regardless of signal strength. The
resulting score is bucketed into
`accumulate / hold_with_upside_watch / hold / avoid_new_entry / reduce_exposure`.

## Requirement mapping (PS-01 minimum requirements)

| Requirement | Where |
|---|---|
| Signal classification across ≥3 dimensions, confidence + reasoning | `agents/momentum_agent.py`, `volume_agent.py`, `sentiment_agent.py` |
| RAG grounding an agent output, attribution visible | `rag.py` (TF-IDF retrieval) + `sentiment_agent.py`, citations returned in every response |
| ≥3 agents in parallel, defined role + structured output contract | `agents/base.py` (`AgentOutput` contract) + `orchestrator.py` (`asyncio.gather`) |
| User profiling modifies output per user on identical input | `profiling.py` + `synthesis_agent.py` risk/concentration weighting — see Quickstart example |
| Live interface: signals, synthesized output, portfolio state | `main.py` `/ws/live/{ticker}` WebSocket + REST equivalents |
| Performance log, ≥3 metrics per session | `logger.py` / `models.py::SessionMetrics` — per-agent latency, total latency, portfolio concentration, avg confidence; `GET /metrics/recent` |
| End-to-end demo, full reasoning chain visible | `GET /analyze/{ticker}` or `run_demo.py` — returns every agent's label/confidence/reasoning/citations plus the synthesis |
| Graceful degraded-data handling, never uncited | `data_feed.py` (`set_degraded`, returns last-known-good data flagged `degraded`) + `orchestrator.py` (`_run_agent_safely` catches per-agent failures) — see `run_demo.py ... --degrade` |
| Written architecture/decision-logic summary | This section, for judges |

## Project layout

```
app/
  data_feed.py        simulated market feed (+ degraded-mode toggle)
  corpus.py            synthetic SEBI filings / earnings transcripts
  rag.py                TF-IDF retrieval over the corpus
  profiling.py          user risk/portfolio store (data/users.json)
  logger.py             performance metrics (JSONL, data/performance_log.jsonl)
  orchestrator.py       parallel agent dispatch + synthesis + logging
  llm.py                 optional Claude hook for richer reasoning text (unused by default)
  models.py              shared dataclasses (the structured output contracts)
  agents/
    base.py               BaseAgent contract
    momentum_agent.py
    volume_agent.py
    sentiment_agent.py
    synthesis_agent.py
  main.py                 FastAPI app (REST + WebSocket)
run_demo.py               no-server CLI demo
requirements.txt
data/
  users.json               seed user profiles (3 risk tiers)
  performance_log.jsonl     created at runtime
```

## Extending this for the real 24 hours

- **Real market data**: replace `MarketDataFeed` internals in `data_feed.py`
  with an NSE/broker websocket client. Keep `get_snapshot()`'s return shape
  (`MarketSnapshot`) the same and nothing downstream needs to change.
- **Real filings corpus**: replace `DOCUMENTS` in `corpus.py` with ingested
  SEBI/BSE/NSE filings, chunked to a similar size. `rag.py`'s `TfidfRetriever`
  works as-is; swap it for a vector DB (pgvector/FAISS) later by keeping the
  `.query()` interface the same.
- **LLM-generated reasoning**: `llm.py` has an isolated, fail-safe hook —
  set `ANTHROPIC_API_KEY` and `pip install anthropic`, then call
  `generate_explanation(prompt)` from inside an agent or the synthesis layer
  to turn structured findings into richer natural-language explanations. It
  returns `None` (falls back to the deterministic text) if unavailable, so
  it's safe to wire in mid-hackathon without breaking the demo.
- **Persistence**: `profiling.py` and `logger.py` are file-backed by design
  so there's zero setup; swap for Postgres/Mongo by changing only those two
  modules' internals.
- **Frontend**: `/ws/live/{ticker}` pushes a full `SynthesisResult` +
  portfolio state every few seconds — enough for a live dashboard without
  any polling logic on the client side.
