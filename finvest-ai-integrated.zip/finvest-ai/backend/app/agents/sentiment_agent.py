"""
Sentiment/fundamentals agent: retrieves relevant earnings-call and filing
excerpts for the ticker and scores tone with a small lexicon, grounding its
output in retrieved source material with visible attribution. This is the
retrieval-augmented-generation component and signal dimension 3 of 3.
"""
from __future__ import annotations

import asyncio

from app.agents.base import BaseAgent
from app.models import AgentOutput, MarketSnapshot, UserProfile
from app.rag import retriever

_POSITIVE_WORDS = {
    "growth", "strength", "healthy", "raised", "improved", "profitable",
    "accelerating", "momentum", "stable", "recovery", "supported", "returns",
}
_NEGATIVE_WORDS = {
    "pressure", "moderated", "cautious", "volatility", "headwind", "burn",
    "outflow", "trimmed", "concerns", "slippages", "penalty", "adverse",
    "aggressive competitive",
}


class SentimentAgent(BaseAgent):
    name = "sentiment_agent"
    dimension = "sentiment"

    async def run(self, snapshot: MarketSnapshot, profile: UserProfile) -> AgentOutput:
        await asyncio.sleep(0.03)  # simulate retrieval latency

        query = f"{snapshot.ticker} recent earnings guidance risk outlook"
        chunks = retriever.query(query, ticker=snapshot.ticker, top_k=2)

        if not chunks:
            return AgentOutput(
                agent_name=self.name,
                dimension=self.dimension,
                label="neutral",
                confidence=0.2,
                reasoning=(
                    f"No relevant filings or transcripts were retrieved for {snapshot.ticker} "
                    f"in the current corpus, so no sentiment signal is asserted."
                ),
                degraded=True,
            )

        pos_hits = 0
        neg_hits = 0
        for chunk in chunks:
            text_lower = chunk.document.text.lower()
            pos_hits += sum(1 for w in _POSITIVE_WORDS if w in text_lower)
            neg_hits += sum(1 for w in _NEGATIVE_WORDS if w in text_lower)

        net = pos_hits - neg_hits
        total_hits = max(pos_hits + neg_hits, 1)
        confidence = min(0.9, 0.35 + (abs(net) / total_hits) * 0.5 + chunks[0].score * 0.15)

        if net > 0:
            label = "positive"
        elif net < 0:
            label = "negative"
        else:
            label = "mixed"

        citations = retriever.to_citations(chunks)
        source_list = "; ".join(f"{c.source}" for c in citations)
        reasoning = (
            f"Retrieved {len(chunks)} document(s) for {snapshot.ticker} ({source_list}). "
            f"Tone analysis found {pos_hits} positive and {neg_hits} negative indicator "
            f"term(s) across the retrieved excerpts, yielding a {label} sentiment read. "
            f"This finding is grounded in the cited source excerpts, not live news."
        )

        return AgentOutput(
            agent_name=self.name,
            dimension=self.dimension,
            label=label,
            confidence=round(confidence, 3),
            reasoning=reasoning,
            citations=citations,
            raw_metrics={
                "positive_hits": pos_hits,
                "negative_hits": neg_hits,
                "top_retrieval_score": round(chunks[0].score, 4),
            },
        )
