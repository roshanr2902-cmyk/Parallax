"""
Momentum agent: evaluates short-term price momentum via rate-of-change and
a simple moving-average crossover. This is signal dimension 1 of 3.
"""
from __future__ import annotations

import asyncio

from app.agents.base import BaseAgent
from app.models import AgentOutput, MarketSnapshot, UserProfile


class MomentumAgent(BaseAgent):
    name = "momentum_agent"
    dimension = "momentum"

    async def run(self, snapshot: MarketSnapshot, profile: UserProfile) -> AgentOutput:
        # Simulate non-trivial async work (e.g. an indicator microservice call)
        await asyncio.sleep(0.02)

        history = snapshot.price_history
        if len(history) < 2:
            return AgentOutput(
                agent_name=self.name,
                dimension=self.dimension,
                label="neutral",
                confidence=0.2,
                reasoning="Insufficient price history to compute momentum reliably.",
                degraded=snapshot.degraded,
            )

        roc = (snapshot.price - history[0]) / history[0] if history[0] else 0.0

        short_window = history[-5:] if len(history) >= 5 else history
        long_window = history[-15:] if len(history) >= 15 else history
        short_ma = sum(short_window) / len(short_window)
        long_ma = sum(long_window) / len(long_window)
        ma_spread = (short_ma - long_ma) / long_ma if long_ma else 0.0

        # Combine rate-of-change and MA spread into a single momentum score
        score = 0.6 * roc + 0.4 * ma_spread
        confidence = min(0.95, 0.4 + abs(score) * 8)  # more movement -> more confidence, capped

        if score > 0.01:
            label = "bullish"
            reasoning = (
                f"Price is up {roc*100:.2f}% over the observed window and the short-term "
                f"moving average sits {ma_spread*100:.2f}% above the longer-term average, "
                f"indicating upward momentum."
            )
        elif score < -0.01:
            label = "bearish"
            reasoning = (
                f"Price is down {roc*100:.2f}% over the observed window and the short-term "
                f"moving average sits {ma_spread*100:.2f}% below the longer-term average, "
                f"indicating downward momentum."
            )
        else:
            label = "neutral"
            confidence = min(confidence, 0.55)
            reasoning = (
                f"Price change of {roc*100:.2f}% and a moving-average spread of "
                f"{ma_spread*100:.2f}% are both within a range considered noise, "
                f"indicating no clear directional momentum."
            )

        if snapshot.degraded:
            reasoning += " Note: computed from last known good data; live feed is currently unavailable."

        return AgentOutput(
            agent_name=self.name,
            dimension=self.dimension,
            label=label,
            confidence=round(confidence, 3),
            reasoning=reasoning,
            raw_metrics={
                "rate_of_change": round(roc, 5),
                "short_ma": round(short_ma, 2),
                "long_ma": round(long_ma, 2),
                "ma_spread": round(ma_spread, 5),
            },
            degraded=snapshot.degraded,
        )
