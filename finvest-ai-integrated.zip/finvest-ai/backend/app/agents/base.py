"""
Base class every specialized agent implements. Enforces the structured
output contract (AgentOutput) that the synthesis layer consumes, per the
"defined role and structured output contract" requirement.
"""
from __future__ import annotations

import time
from abc import ABC, abstractmethod

from app.models import AgentOutput, MarketSnapshot, UserProfile


class BaseAgent(ABC):
    name: str = "base_agent"
    dimension: str = "undefined"

    @abstractmethod
    async def run(self, snapshot: MarketSnapshot, profile: UserProfile) -> AgentOutput:
        """Execute this agent's analysis and return a structured AgentOutput."""
        raise NotImplementedError

    async def timed_run(self, snapshot: MarketSnapshot, profile: UserProfile) -> tuple[AgentOutput, float]:
        start = time.perf_counter()
        output = await self.run(snapshot, profile)
        latency_ms = (time.perf_counter() - start) * 1000
        return output, latency_ms
