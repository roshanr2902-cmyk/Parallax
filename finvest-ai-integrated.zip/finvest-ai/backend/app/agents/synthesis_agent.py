"""
Synthesis layer: consumes the structured outputs of all parallel signal
agents, weights them against the user's stored risk profile and existing
position, and produces one explainable, cited recommendation. This is the
"connective tissue" the problem statement calls out as the differentiator.

Critically, this stage never fabricates support for its conclusion: every
citation it surfaces is one already produced by an upstream agent (mainly
the RAG-grounded sentiment agent), and degraded inputs are always disclosed
rather than silently treated as normal data.
"""
from __future__ import annotations

from typing import List

from app.models import AgentOutput, Citation, MarketSnapshot, SynthesisResult, UserProfile

_LABEL_SCORE = {
    "bullish": 1, "positive": 1, "elevated": 0,  # elevated volume is directional-agnostic
    "neutral": 0, "mixed": 0, "normal": 0, "depressed": 0,
    "bearish": -1, "negative": -1,
}

_RISK_MULTIPLIER = {
    "conservative": 0.7,   # conservative users need a stronger signal before acting
    "moderate": 1.0,
    "aggressive": 1.3,
}


class SynthesisAgent:
    name = "synthesis_agent"

    def run(
        self,
        snapshot: MarketSnapshot,
        profile: UserProfile,
        agent_outputs: List[AgentOutput],
    ) -> SynthesisResult:
        directional = [o for o in agent_outputs if o.dimension in ("momentum", "sentiment")]
        weighted_score = sum(
            _LABEL_SCORE.get(o.label, 0) * o.confidence for o in directional
        )
        avg_confidence = sum(o.confidence for o in agent_outputs) / max(len(agent_outputs), 1)

        volume_output = next((o for o in agent_outputs if o.dimension == "volume_anomaly"), None)
        volume_amplifier = 1.15 if volume_output and volume_output.label == "elevated" else 1.0

        risk_mult = _RISK_MULTIPLIER.get(profile.risk_tolerance, 1.0)
        concentration = profile.concentration_score(snapshot.ticker)

        # A concentrated existing position dampens the case for adding more,
        # regardless of how bullish the signal looks -- this is what makes
        # the same market input produce a different output per user.
        concentration_penalty = 1.0 - min(concentration, 0.6)

        final_score = weighted_score * volume_amplifier * risk_mult * concentration_penalty

        if final_score >= 0.5:
            recommendation = "accumulate"
        elif final_score >= 0.15:
            recommendation = "hold_with_upside_watch"
        elif final_score <= -0.5:
            recommendation = "reduce_exposure"
        elif final_score <= -0.15:
            recommendation = "avoid_new_entry"
        else:
            recommendation = "hold"

        if concentration >= 0.4 and recommendation == "accumulate":
            recommendation = "hold_with_upside_watch"

        degraded_dims = [o.dimension for o in agent_outputs if o.degraded]

        citations: List[Citation] = []
        for o in agent_outputs:
            citations.extend(o.citations)

        summary_parts = [
            f"For {snapshot.ticker}, momentum and sentiment signals combine to a "
            f"weighted score of {weighted_score:.2f} (before risk adjustment)."
        ]
        if volume_output and volume_output.label == "elevated":
            summary_parts.append("Elevated volume amplifies confidence in this reading.")
        summary_parts.append(
            f"Adjusted for a {profile.risk_tolerance} risk profile and an existing "
            f"{concentration*100:.1f}% portfolio concentration in {snapshot.ticker}, "
            f"the resulting guidance is '{recommendation}'."
        )
        if degraded_dims:
            summary_parts.append(
                f"Note: the following input dimension(s) were computed from degraded "
                f"or stale data and should be treated with reduced confidence: "
                f"{', '.join(degraded_dims)}."
            )
        if citations:
            summary_parts.append(
                f"This recommendation is grounded in {len(citations)} cited source excerpt(s); "
                f"see citations for attribution."
            )
        else:
            summary_parts.append(
                "No source documents were retrieved for the sentiment dimension in this "
                "session, so the sentiment component of this recommendation carries low weight."
            )

        return SynthesisResult(
            ticker=snapshot.ticker,
            user_id=profile.user_id,
            recommendation=recommendation,
            confidence=round(min(avg_confidence, 0.95), 3),
            summary=" ".join(summary_parts),
            agent_outputs=agent_outputs,
            citations=citations,
            degraded_inputs=degraded_dims,
        )
