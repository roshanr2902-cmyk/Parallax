"""
Volume anomaly agent: flags unusual trading volume relative to a rolling
average using a simple z-score style comparison. Signal dimension 2 of 3.
"""
from __future__ import annotations

import asyncio
import statistics

from app.agents.base import BaseAgent
from app.models import AgentOutput, MarketSnapshot, UserProfile


class VolumeAgent(BaseAgent):
    name = "volume_agent"
    dimension = "volume_anomaly"

    async def run(self, snapshot: MarketSnapshot, profile: UserProfile) -> AgentOutput:
        await asyncio.sleep(0.015)

        avg = snapshot.avg_volume_20d
        ratio = snapshot.volume / avg if avg else 1.0

        if ratio >= 1.8:
            label = "elevated"
            confidence = min(0.95, 0.5 + (ratio - 1.8) * 0.2)
            reasoning = (
                f"Current volume is {ratio:.2f}x the 20-day average, a significant spike "
                f"that often precedes or confirms a directional move."
            )
        elif ratio <= 0.5:
            label = "depressed"
            confidence = min(0.9, 0.5 + (0.5 - ratio) * 0.4)
            reasoning = (
                f"Current volume is only {ratio:.2f}x the 20-day average, suggesting "
                f"low conviction and reduced liquidity in current price moves."
            )
        else:
            label = "normal"
            confidence = 0.6
            reasoning = (
                f"Current volume is {ratio:.2f}x the 20-day average, within a normal "
                f"range with no notable anomaly."
            )

        if snapshot.degraded:
            reasoning += " Note: computed from last known good data; live feed is currently unavailable."

        return AgentOutput(
            agent_name=self.name,
            dimension=self.dimension,
            label=label,
            confidence=round(confidence, 3),
            reasoning=reasoning,
            raw_metrics={
                "volume": snapshot.volume,
                "avg_volume_20d": round(avg, 2),
                "volume_ratio": round(ratio, 3),
            },
            degraded=snapshot.degraded,
        )
