"""
Synthetic regulatory/financial disclosure corpus.

Stands in for real SEBI filings, earnings call transcripts, and FII flow
disclosures per the problem statement's "or equivalent synthetic documents"
allowance. Swap `DOCUMENTS` for a real ingestion pipeline (e.g. scraped
SEBI/BSE/NSE filings, chunked) without touching the retrieval or agent code.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Document:
    doc_id: str
    source: str
    ticker: str
    text: str


DOCUMENTS: list[Document] = [
    Document(
        doc_id="RELIANCE-Q2FY26-EARNINGS-01",
        source="Reliance Industries Q2 FY26 Earnings Call Transcript",
        ticker="RELIANCE",
        text=(
            "Management highlighted continued strength in the retail and digital "
            "services segments, with retail revenue growing double digits year "
            "on year. Refining margins moderated slightly due to global crude "
            "volatility. Management reiterated capex guidance for new energy "
            "investments over the next three years and flagged near-term margin "
            "pressure in the petrochemicals division."
        ),
    ),
    Document(
        doc_id="RELIANCE-SEBI-FILING-04",
        source="SEBI Corporate Filing - Reliance Industries",
        ticker="RELIANCE",
        text=(
            "The company disclosed a related-party transaction involving asset "
            "transfer between subsidiaries, filed in compliance with disclosure "
            "norms. No material adverse impact on consolidated financials is "
            "indicated. Promoter shareholding remains unchanged this quarter."
        ),
    ),
    Document(
        doc_id="TCS-Q2FY26-EARNINGS-01",
        source="TCS Q2 FY26 Earnings Call Transcript",
        ticker="TCS",
        text=(
            "Deal wins remained healthy but management flagged cautious client "
            "spending in North American BFSI accounts amid macro uncertainty. "
            "Attrition improved sequentially. Management guided for steady but "
            "unspectacular revenue growth and highlighted continued investment "
            "in AI-led service offerings."
        ),
    ),
    Document(
        doc_id="TCS-FII-FLOW-02",
        source="FII Flow Disclosure Summary - IT Sector",
        ticker="TCS",
        text=(
            "Foreign institutional investors trimmed holdings across large-cap "
            "IT services names over the past month amid concerns about US "
            "discretionary tech spending. Domestic institutional flows partially "
            "offset the outflow."
        ),
    ),
    Document(
        doc_id="INFY-Q2FY26-EARNINGS-01",
        source="Infosys Q2 FY26 Earnings Call Transcript",
        ticker="INFY",
        text=(
            "Management raised full-year revenue growth guidance modestly, "
            "citing large deal momentum and stable discretionary spending "
            "recovery. Margins were supported by cost optimization initiatives. "
            "Management flagged currency volatility as a watch item."
        ),
    ),
    Document(
        doc_id="INFY-SEBI-FILING-02",
        source="SEBI Corporate Filing - Infosys",
        ticker="INFY",
        text=(
            "The company filed disclosure regarding a new share buyback "
            "program, subject to board and shareholder approval. The buyback "
            "is intended to return surplus cash to shareholders and is not "
            "linked to any adverse business development."
        ),
    ),
    Document(
        doc_id="HDFCBANK-Q2FY26-EARNINGS-01",
        source="HDFC Bank Q2 FY26 Earnings Call Transcript",
        ticker="HDFCBANK",
        text=(
            "Management reported steady deposit growth and continued progress "
            "on the merger integration cost synergies. Asset quality remained "
            "stable with no significant increase in slippages. Management "
            "flagged elevated funding costs as a near-term margin headwind."
        ),
    ),
    Document(
        doc_id="HDFCBANK-SEBI-FILING-01",
        source="SEBI Corporate Filing - HDFC Bank",
        ticker="HDFCBANK",
        text=(
            "The bank disclosed routine board-approved changes to senior "
            "management responsibilities. No regulatory action or penalty was "
            "reported in the filing period."
        ),
    ),
    Document(
        doc_id="ZOMATO-Q2FY26-EARNINGS-01",
        source="Zomato (Eternal) Q2 FY26 Earnings Call Transcript",
        ticker="ZOMATO",
        text=(
            "Management highlighted accelerating quick-commerce order volumes "
            "alongside continued cash burn in that segment as the company scales "
            "dark store network. Food delivery segment turned more profitable. "
            "Management flagged aggressive competitive intensity in "
            "quick-commerce as a key watch item for margins."
        ),
    ),
    Document(
        doc_id="ZOMATO-FII-FLOW-01",
        source="FII Flow Disclosure Summary - Consumer Internet",
        ticker="ZOMATO",
        text=(
            "Foreign institutional flows into new-age consumer internet stocks "
            "were mixed this quarter, with some funds trimming positions on "
            "valuation concerns while others added on quick-commerce growth "
            "optionality."
        ),
    ),
]
