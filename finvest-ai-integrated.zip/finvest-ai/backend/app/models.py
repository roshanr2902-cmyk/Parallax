"""
Shared data contracts used across data feed, agents, RAG, and orchestrator.

Deliberately plain dataclasses (not pydantic) so the core logic has zero
framework dependency and can be unit-tested without FastAPI installed.
FastAPI-facing request/response schemas live in app/main.py instead.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class Citation:
    source: str
    snippet: str
    score: float


@dataclass
class MarketSnapshot:
    """One tick of market data for a single ticker."""
    ticker: str
    price: float
    prev_close: float
    price_history: List[float]          # most recent N prices, oldest -> newest
    volume: float
    avg_volume_20d: float
    timestamp: str = field(default_factory=utcnow_iso)
    degraded: bool = False               # True if this snapshot is a fallback/stale value
    degraded_reason: Optional[str] = None


@dataclass
class AgentOutput:
    """Structured, required output contract every signal agent must produce."""
    agent_name: str
    dimension: str                       # e.g. "momentum" | "volume_anomaly" | "sentiment"
    label: str                           # e.g. "bullish" | "bearish" | "neutral" | "elevated"
    confidence: float                    # 0.0 - 1.0
    reasoning: str
    citations: List[Citation] = field(default_factory=list)
    raw_metrics: Dict[str, Any] = field(default_factory=dict)
    degraded: bool = False
    timestamp: str = field(default_factory=utcnow_iso)


@dataclass
class UserProfile:
    user_id: str
    risk_tolerance: str                  # "conservative" | "moderate" | "aggressive"
    portfolio: Dict[str, float]          # ticker -> position value (INR)
    watchlist: List[str]
    history: List[str] = field(default_factory=list)  # short log of past interactions

    def portfolio_value(self) -> float:
        return sum(self.portfolio.values())

    def concentration_score(self, ticker: str) -> float:
        """Fraction of portfolio value already sitting in this ticker (0-1)."""
        total = self.portfolio_value()
        if total <= 0:
            return 0.0
        return round(self.portfolio.get(ticker, 0.0) / total, 4)


@dataclass
class SynthesisResult:
    ticker: str
    user_id: str
    recommendation: str                  # e.g. "reduce_exposure" | "hold" | "accumulate" | "avoid_new_entry"
    confidence: float
    summary: str
    agent_outputs: List[AgentOutput]
    citations: List[Citation]
    degraded_inputs: List[str]           # names of dimensions that were degraded
    timestamp: str = field(default_factory=utcnow_iso)


@dataclass
class SessionMetrics:
    session_id: str
    ticker: str
    user_id: str
    agent_latency_ms: Dict[str, float]
    total_latency_ms: float
    portfolio_risk_concentration: float
    signal_confidence_avg: float
    degraded_dimension_count: int
    timestamp: str = field(default_factory=utcnow_iso)
