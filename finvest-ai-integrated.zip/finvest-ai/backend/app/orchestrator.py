"""
Orchestrator: the "multi-agent orchestration framework" required by the
problem statement. Dispatches the three signal agents in parallel via
asyncio.gather, ensures a partial agent failure degrades gracefully instead
of crashing the pipeline, runs the synthesis layer, and logs performance
metrics for the session.
"""
from __future__ import annotations

import time
import uuid
from typing import List

from app.agents import MomentumAgent, SentimentAgent, SynthesisAgent, VolumeAgent
from app.agents.base import BaseAgent
from app.data_feed import feed
from app.logger import log_session
from app.models import AgentOutput, MarketSnapshot, SessionMetrics, SynthesisResult, UserProfile
from app.profiling import store

_AGENTS: List[BaseAgent] = [MomentumAgent(), VolumeAgent(), SentimentAgent()]
_SYNTHESIS = SynthesisAgent()


async def _run_agent_safely(agent: BaseAgent, snapshot: MarketSnapshot, profile: UserProfile):
    """
    Wraps a single agent so that if it raises, the pipeline degrades that one
    dimension instead of failing the whole session -- this is the
    "conflicting/missing signal from an agent" half of the degraded-data
    requirement (the other half, an unavailable data feed, is handled in
    data_feed.py).
    """
    try:
        output, latency_ms = await agent.timed_run(snapshot, profile)
        return output, latency_ms
    except Exception as exc:  # noqa: BLE001 - deliberately broad, this is a safety boundary
        fallback = AgentOutput(
            agent_name=agent.name,
            dimension=agent.dimension,
            label="neutral",
            confidence=0.0,
            reasoning=(
                f"{agent.name} failed to produce a signal ({type(exc).__name__}); "
                f"this dimension has been excluded from the recommendation rather "
                f"than guessed at."
            ),
            degraded=True,
        )
        return fallback, 0.0


async def run_session(ticker: str, user_id: str) -> SynthesisResult:
    session_id = str(uuid.uuid4())
    session_start = time.perf_counter()

    snapshot = feed.get_snapshot(ticker)
    profile = store.get(user_id)

    results = await __import__("asyncio").gather(
        *[_run_agent_safely(agent, snapshot, profile) for agent in _AGENTS]
    )
    agent_outputs = [r[0] for r in results]
    latencies = {agent.name: r[1] for agent, r in zip(_AGENTS, results)}

    synthesis = _SYNTHESIS.run(snapshot, profile, agent_outputs)

    total_latency_ms = (time.perf_counter() - session_start) * 1000
    avg_confidence = sum(o.confidence for o in agent_outputs) / max(len(agent_outputs), 1)

    metrics = SessionMetrics(
        session_id=session_id,
        ticker=ticker,
        user_id=user_id,
        agent_latency_ms={k: round(v, 2) for k, v in latencies.items()},
        total_latency_ms=round(total_latency_ms, 2),
        portfolio_risk_concentration=profile.concentration_score(ticker),
        signal_confidence_avg=round(avg_confidence, 3),
        degraded_dimension_count=len(synthesis.degraded_inputs),
    )
    log_session(metrics)
    store.record_interaction(
        user_id, f"queried {ticker} -> {synthesis.recommendation} (session {session_id[:8]})"
    )

    return synthesis
