"""
Optional LLM-backed reasoning generator.

The whole system works end-to-end with zero API keys using deterministic,
template-based reasoning (see agents/*.py). If ANTHROPIC_API_KEY is set and
the `anthropic` package is installed, this module can be used to rewrite
structured findings into a more natural explanation for the synthesis
summary. This is intentionally isolated so a missing key/package never
breaks the demo -- it just silently falls back.

Usage (optional, e.g. inside synthesis_agent.py):

    from app.llm import generate_explanation
    text = await generate_explanation(prompt)  # returns None if unavailable
"""
from __future__ import annotations

import os
from typing import Optional

_ANTHROPIC_AVAILABLE = False
try:
    import anthropic  # type: ignore
    _ANTHROPIC_AVAILABLE = True
except ImportError:
    pass


async def generate_explanation(prompt: str, max_tokens: int = 300) -> Optional[str]:
    """Return an LLM-generated explanation, or None if no key/package is available."""
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not (_ANTHROPIC_AVAILABLE and api_key):
        return None

    try:
        client = anthropic.Anthropic(api_key=api_key)
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )
        parts = [b.text for b in response.content if getattr(b, "type", None) == "text"]
        return "\n".join(parts).strip() or None
    except Exception:
        # Never let an LLM outage break the pipeline -- fall back to
        # deterministic reasoning generated locally.
        return None
