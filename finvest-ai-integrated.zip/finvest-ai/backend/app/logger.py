"""
Performance and session logging.

Captures, per session: per-agent latency, total pipeline latency, portfolio
risk concentration, and average signal confidence -- at least three
measurable metrics as required. Appends newline-delimited JSON so the log
is trivial to tail, parse, or stream into a dashboard.
"""
from __future__ import annotations

import json
import os
from dataclasses import asdict

from app.models import SessionMetrics

_LOG_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "performance_log.jsonl")


def log_session(metrics: SessionMetrics) -> None:
    os.makedirs(os.path.dirname(_LOG_PATH), exist_ok=True)
    with open(_LOG_PATH, "a") as f:
        f.write(json.dumps(asdict(metrics)) + "\n")


def read_recent_sessions(limit: int = 20) -> list[dict]:
    if not os.path.exists(_LOG_PATH):
        return []
    with open(_LOG_PATH, "r") as f:
        lines = f.readlines()
    return [json.loads(line) for line in lines[-limit:]]
