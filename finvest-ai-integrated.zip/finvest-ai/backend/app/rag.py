"""
Retrieval layer for the sentiment/fundamentals agent.

Uses TF-IDF + cosine similarity (scikit-learn) rather than an external
embeddings API, so retrieval works fully offline with no API key and no
network dependency -- important for a 24-hour hackathon demo environment.
Swap `TfidfRetriever` for a real vector DB (pgvector/FAISS/Pinecone) later
without touching the agent code, since the public interface (`query`) is
the same shape either way.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from app.corpus import DOCUMENTS, Document
from app.models import Citation


@dataclass
class RetrievedChunk:
    document: Document
    score: float


class TfidfRetriever:
    def __init__(self, documents: List[Document] | None = None) -> None:
        self.documents = documents if documents is not None else DOCUMENTS
        self._vectorizer = TfidfVectorizer(stop_words="english")
        # Vectorize source metadata + body together: filing/transcript titles
        # ("Earnings Call Transcript", "FII Flow Disclosure") carry topical
        # signal that the body text alone often lacks for a short corpus.
        self._matrix = self._vectorizer.fit_transform(
            [f"{d.source}. {d.text}" for d in self.documents]
        )

    def query(self, text: str, ticker: str | None = None, top_k: int = 2) -> List[RetrievedChunk]:
        """Return the top_k most relevant chunks, optionally scoped to a ticker."""
        candidate_idx = [
            i for i, d in enumerate(self.documents)
            if ticker is None or d.ticker == ticker
        ]
        if not candidate_idx:
            return []

        query_vec = self._vectorizer.transform([text])
        sims = cosine_similarity(query_vec, self._matrix[candidate_idx]).flatten()

        ranked = sorted(
            zip(candidate_idx, sims), key=lambda pair: pair[1], reverse=True
        )[:top_k]

        return [
            RetrievedChunk(document=self.documents[idx], score=float(score))
            for idx, score in ranked
            if score > 0.0
        ]

    @staticmethod
    def to_citations(chunks: List[RetrievedChunk]) -> List[Citation]:
        return [
            Citation(
                source=c.document.source,
                snippet=(c.document.text[:180] + "...") if len(c.document.text) > 180 else c.document.text,
                score=round(c.score, 4),
            )
            for c in chunks
        ]


# module-level singleton, built once at startup (TF-IDF fit is cheap for this corpus size)
retriever = TfidfRetriever()
