"""
FastAPI wiring for the multi-agent financial intelligence backend.

Endpoints:
  GET  /tickers                          -> list available tickers
  GET  /market/{ticker}                  -> raw market snapshot (with degraded flag)
  GET  /profile/{user_id}                -> stored user profile
  POST /profile/{user_id}                -> upsert risk_tolerance/portfolio/watchlist
  GET  /analyze/{ticker}?user_id=...     -> full pipeline: 3 agents + synthesis (end-to-end demo endpoint)
  POST /admin/degrade/{ticker}           -> force a ticker's feed into a degraded state (for demoing graceful handling)
  GET  /metrics/recent                   -> recent performance log entries
  WS   /ws/live/{ticker}                 -> streams a fresh analysis every few seconds (live interface)

Run with:
    uvicorn app.main:app --reload --port 8000
"""
from __future__ import annotations

import asyncio
from dataclasses import asdict
from typing import Dict, List, Optional

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from app.data_feed import feed
from app.logger import read_recent_sessions
from app.models import UserProfile
from app.orchestrator import run_session
from app.profiling import store

app = FastAPI(
    title="HackVerse PS-01 — Multi-Agent Financial Intelligence Backend",
    description=(
        "Multi-agent orchestration over simulated market data and a synthetic "
        "regulatory/earnings corpus, producing explainable, per-user "
        "investment guidance with source attribution."
    ),
    version="0.1.0",
)

# Wide-open CORS for hackathon demo purposes; tighten before any real deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------- request/response schemas (FastAPI-facing only) ----------

class ProfileUpdate(BaseModel):
    risk_tolerance: str  # "conservative" | "moderate" | "aggressive"
    portfolio: Dict[str, float] = {}
    watchlist: List[str] = []


# ---------- REST endpoints ----------

@app.get("/tickers")
def list_tickers():
    return {"tickers": feed.list_tickers()}


@app.get("/market/{ticker}")
def get_market_snapshot(ticker: str):
    try:
        snapshot = feed.get_snapshot(ticker.upper())
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Unknown ticker: {ticker}")
    return asdict(snapshot)


@app.get("/profile/{user_id}")
def get_profile(user_id: str):
    profile = store.get(user_id)
    return asdict(profile)


@app.post("/profile/{user_id}")
def upsert_profile(user_id: str, update: ProfileUpdate):
    profile = UserProfile(
        user_id=user_id,
        risk_tolerance=update.risk_tolerance,
        portfolio=update.portfolio,
        watchlist=update.watchlist,
    )
    store.upsert(profile)
    return asdict(profile)


@app.get("/analyze/{ticker}")
async def analyze(ticker: str, user_id: str = "user_moderate_01"):
    """
    The end-to-end demo endpoint: raw data -> 3 parallel agents -> synthesis
    -> user-facing recommendation, full reasoning chain included.
    """
    try:
        result = await run_session(ticker.upper(), user_id)
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Unknown ticker: {ticker}")
    return asdict(result)


@app.post("/admin/degrade/{ticker}")
def set_degraded(ticker: str, degraded: bool = True):
    """Force a ticker's feed into (or out of) a degraded state, for demoing
    the graceful degraded-data handling requirement live."""
    try:
        feed.set_degraded(ticker.upper(), degraded)
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Unknown ticker: {ticker}")
    return {"ticker": ticker.upper(), "degraded": degraded}


@app.get("/metrics/recent")
def metrics_recent(limit: int = 20):
    return {"sessions": read_recent_sessions(limit)}


# ---------- WebSocket: live interface layer ----------

@app.websocket("/ws/live/{ticker}")
async def ws_live(websocket: WebSocket, ticker: str, user_id: str = "user_moderate_01", interval_seconds: float = 4.0):
    """
    Streams a fresh multi-agent analysis for `ticker` every `interval_seconds`,
    satisfying the "live interface rendering current market signals,
    synthesized output, and portfolio state" requirement.
    """
    await websocket.accept()
    ticker = ticker.upper()
    try:
        while True:
            try:
                result = await run_session(ticker, user_id)
                profile = store.get(user_id)
                await websocket.send_json({
                    "type": "analysis_update",
                    "synthesis": asdict(result),
                    "portfolio_state": {
                        "portfolio": profile.portfolio,
                        "watchlist": profile.watchlist,
                        "concentration_in_ticker": profile.concentration_score(ticker),
                    },
                })
            except KeyError:
                await websocket.send_json({"type": "error", "detail": f"Unknown ticker: {ticker}"})
                break
            await asyncio.sleep(interval_seconds)
    except WebSocketDisconnect:
        pass


@app.get("/")
def root():
    return {
        "service": "HackVerse PS-01 backend",
        "docs": "/docs",
        "try": "/analyze/RELIANCE?user_id=user_conservative_01",
    }
