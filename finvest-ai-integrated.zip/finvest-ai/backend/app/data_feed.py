"""
Simulated real-time market data source.

In a real deployment this would wrap NSE/broker websocket feeds. For the
hackathon demo it generates plausible random-walk price/volume series per
ticker, and can be forced into a degraded state (feed unavailable / stale
data) to exercise the "graceful degraded-data handling" requirement.
"""
from __future__ import annotations

import random
from typing import Dict, List

from app.models import MarketSnapshot, utcnow_iso

_SEED_PRICES = {
    "RELIANCE": 2950.0,
    "TCS": 4120.0,
    "INFY": 1850.0,
    "HDFCBANK": 1680.0,
    "ZOMATO": 265.0,
}


class MarketDataFeed:
    """Stateful in-memory feed. One instance per running server."""

    def __init__(self, seed: int | None = 42) -> None:
        self._rng = random.Random(seed)
        self._price_history: Dict[str, List[float]] = {
            t: [p] for t, p in _SEED_PRICES.items()
        }
        self._volume_history: Dict[str, List[float]] = {
            t: [self._rng.uniform(2_000_000, 6_000_000)] for t in _SEED_PRICES
        }
        # tickers currently forced into a degraded state, for demo purposes
        self._force_degraded: set[str] = set()

    def list_tickers(self) -> List[str]:
        return list(_SEED_PRICES.keys())

    def set_degraded(self, ticker: str, degraded: bool) -> None:
        if degraded:
            self._force_degraded.add(ticker)
        else:
            self._force_degraded.discard(ticker)

    def _advance(self, ticker: str) -> None:
        last = self._price_history[ticker][-1]
        drift = self._rng.uniform(-0.015, 0.015)
        new_price = max(0.5, round(last * (1 + drift), 2))
        self._price_history[ticker].append(new_price)
        if len(self._price_history[ticker]) > 30:
            self._price_history[ticker].pop(0)

        last_vol = self._volume_history[ticker][-1]
        vol_shock = self._rng.uniform(-0.3, 0.6)  # volume spikes more than it drops
        new_vol = max(10_000, last_vol * (1 + vol_shock))
        self._volume_history[ticker].append(new_vol)
        if len(self._volume_history[ticker]) > 20:
            self._volume_history[ticker].pop(0)

    def get_snapshot(self, ticker: str) -> MarketSnapshot:
        if ticker not in _SEED_PRICES:
            raise KeyError(f"Unknown ticker: {ticker}")

        if ticker in self._force_degraded:
            # Simulate an unavailable/stale feed: return last known good data,
            # flagged as degraded, rather than raising or fabricating a value.
            hist = self._price_history[ticker]
            vol_hist = self._volume_history[ticker]
            return MarketSnapshot(
                ticker=ticker,
                price=hist[-1],
                prev_close=hist[-2] if len(hist) > 1 else hist[-1],
                price_history=list(hist),
                volume=vol_hist[-1],
                avg_volume_20d=sum(vol_hist) / len(vol_hist),
                timestamp=utcnow_iso(),
                degraded=True,
                degraded_reason="live_feed_unavailable_using_last_known_good_data",
            )

        self._advance(ticker)
        hist = self._price_history[ticker]
        vol_hist = self._volume_history[ticker]
        return MarketSnapshot(
            ticker=ticker,
            price=hist[-1],
            prev_close=hist[-2] if len(hist) > 1 else hist[-1],
            price_history=list(hist),
            volume=vol_hist[-1],
            avg_volume_20d=sum(vol_hist) / len(vol_hist),
        )


# module-level singleton used by the orchestrator / API layer
feed = MarketDataFeed()
