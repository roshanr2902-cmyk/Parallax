"""
User profiling component.

Stores per-user risk tolerance, portfolio composition, and watchlist, and
is the mechanism by which identical market inputs produce different
synthesized outputs for different users (see SynthesisAgent, which reads
`risk_tolerance` and portfolio concentration off the returned UserProfile).

Backed by a JSON file for the demo; swap `_load()`/`_save()` for a real
database (Postgres/Mongo) without touching any calling code.
"""
from __future__ import annotations

import json
import os
from typing import Dict

from app.models import UserProfile

_DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "users.json")


class ProfileStore:
    def __init__(self, path: str = _DATA_PATH) -> None:
        self.path = path
        self._profiles: Dict[str, UserProfile] = {}
        self._load()

    def _load(self) -> None:
        if not os.path.exists(self.path):
            self._profiles = {}
            return
        with open(self.path, "r") as f:
            raw = json.load(f)
        self._profiles = {
            uid: UserProfile(
                user_id=uid,
                risk_tolerance=data["risk_tolerance"],
                portfolio=data.get("portfolio", {}),
                watchlist=data.get("watchlist", []),
                history=data.get("history", []),
            )
            for uid, data in raw.items()
        }

    def _save(self) -> None:
        raw = {
            uid: {
                "risk_tolerance": p.risk_tolerance,
                "portfolio": p.portfolio,
                "watchlist": p.watchlist,
                "history": p.history,
            }
            for uid, p in self._profiles.items()
        }
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w") as f:
            json.dump(raw, f, indent=2)

    def get(self, user_id: str) -> UserProfile:
        if user_id not in self._profiles:
            # Unknown users get a conservative default profile rather than an error,
            # so the API stays usable during a live demo with new user IDs.
            self._profiles[user_id] = UserProfile(
                user_id=user_id, risk_tolerance="moderate", portfolio={}, watchlist=[]
            )
        return self._profiles[user_id]

    def record_interaction(self, user_id: str, note: str) -> None:
        profile = self.get(user_id)
        profile.history.append(note)
        profile.history = profile.history[-20:]  # keep it bounded
        self._save()

    def upsert(self, profile: UserProfile) -> None:
        self._profiles[profile.user_id] = profile
        self._save()


store = ProfileStore()
